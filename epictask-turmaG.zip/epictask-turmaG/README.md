# Epick Task [TURMA 2TDS G]

App de controle de tarefas gamificado para equipes auto gerenciáveis.

## Contexto

Esse repositório faz parte da disciplina de Digital Business Enablement da FIAP

## Funcionalidades

- [X] Tratamento inicial das rotas
- [X] Template com Thymeleaf
- [X] Cadastro de usuário
- [X] Validação dos dados de cadastro
- [ ] Lista de usuários
- [ ] Exclusão de usuários
- [ ] Internacionalização

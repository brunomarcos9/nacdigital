INSERT INTO users (name, email, pass) VALUES 
('Joao Carlos Lima', 'joaocarlos@fiap.com.br', '1234567890');


INSERT INTO tasks(title, description, point, status) VALUES
('Analise', 'Analisar documentação', 100, 90);
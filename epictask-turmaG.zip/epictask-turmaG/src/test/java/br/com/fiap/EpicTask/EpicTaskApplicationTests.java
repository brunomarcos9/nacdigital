package br.com.fiap.EpicTask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EpicTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
